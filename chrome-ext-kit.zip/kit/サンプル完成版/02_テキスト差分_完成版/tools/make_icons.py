# -*- coding: utf-8 -*-
"""
テキスト差分チェッカー用アイコン生成スクリプト

icons/ フォルダに 16 / 32 / 48 / 128 px の PNG を書き出します。
図案：左右に分かれた2つの面（左＝消えた側の赤、右＝増えた側の緑）と、
      それぞれの中央に置いた「−」「＋」の記号。

■ 使い方
    1. Python と Pillow が入っていることを確認する
         pip install pillow
    2. このファイルがある tools フォルダで実行する
         python make_icons.py
    3. 一つ上の icons フォルダに 4 枚の PNG が上書き保存される

■ 色や形を変えたいとき
    下の「調整できる値」だけを書き換えれば、全サイズに反映されます。
"""

import os
import sys

try:
    from PIL import Image, ImageDraw
except ImportError:
    sys.exit("Pillow が見つかりません。先に `pip install pillow` を実行してください。")

# ------------------------------------------------------------------
# 調整できる値
# ------------------------------------------------------------------
SIZES = (16, 32, 48, 128)           # 書き出すサイズ
BG_COLOR = (31, 95, 122, 255)       # 外枠（藍）
DEL_COLOR = (248, 214, 214, 255)    # 左の面（消えた側）
ADD_COLOR = (198, 233, 210, 255)    # 右の面（増えた側）
DEL_MARK = (151, 48, 47, 255)       # 「−」の色
ADD_MARK = (30, 107, 58, 255)       # 「＋」の色
GAP_COLOR = (253, 252, 249, 255)    # 真ん中の仕切り
SS = 8                              # 内部で何倍に拡大して描くか（大きいほど滑らか）

CORNER = 0.235                      # 外枠の角丸
MARGIN = 0.045                      # 外周の余白
INNER = 0.115                       # 外枠の内側の余白
INNER_CORNER = 0.10                 # 内側の面の角丸
GAP = 0.045                         # 真ん中の仕切りの幅
MARK_W = 0.150                      # 記号の長さ
MARK_T = 0.052                      # 記号の太さ
# ------------------------------------------------------------------


def draw_icon(side):
    """1辺 side ピクセルのアイコンを描いて返す（あとで縮小する前提の大きさ）。"""
    img = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    m = side * MARGIN
    d.rounded_rectangle([m, m, side - m, side - m],
                        radius=side * CORNER, fill=BG_COLOR)

    i = side * INNER
    left, top, right, bottom = i, i, side - i, side - i
    cx = side / 2
    gap = side * GAP / 2
    r = side * INNER_CORNER

    # 左の面（消えた側）と右の面（増えた側）
    d.rounded_rectangle([left, top, cx - gap, bottom], radius=r, fill=DEL_COLOR)
    d.rounded_rectangle([cx + gap, top, right, bottom], radius=r, fill=ADD_COLOR)

    # 真ん中の仕切り
    d.rectangle([cx - gap, top, cx + gap, bottom], fill=GAP_COLOR)

    # 「−」（左）
    w = side * MARK_W / 2
    t = side * MARK_T / 2
    lx = (left + cx - gap) / 2
    cy = side / 2
    d.rounded_rectangle([lx - w, cy - t, lx + w, cy + t], radius=t, fill=DEL_MARK)

    # 「＋」（右）
    rx = (cx + gap + right) / 2
    d.rounded_rectangle([rx - w, cy - t, rx + w, cy + t], radius=t, fill=ADD_MARK)
    d.rounded_rectangle([rx - t, cy - w, rx + t, cy + w], radius=t, fill=ADD_MARK)

    return img


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    out_dir = os.path.join(os.path.dirname(here), "icons")
    os.makedirs(out_dir, exist_ok=True)

    for size in SIZES:
        big = draw_icon(size * SS)
        small = big.resize((size, size), Image.LANCZOS)
        path = os.path.join(out_dir, "icon{}.png".format(size))
        small.save(path, "PNG")
        print("書き出しました:", path)


if __name__ == "__main__":
    main()
