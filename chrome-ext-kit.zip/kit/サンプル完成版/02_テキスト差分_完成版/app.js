/*
 * app.js — テキスト差分チェッカー 本体
 *
 * 中身は大きく4つに分かれています。
 *   1. 小さな道具（保存・トースト・小窓の移動）
 *   2. 文章を単位に切り分ける（行 / 単語 / 文字）
 *   3. 差分を求める（最長共通部分列 ＝ LCS）
 *   4. 画面に描く
 *
 * 外部ライブラリは使っていません。差分の計算も自前です。
 */

'use strict';

/* =========================================================
   0. 定数と状態
   ========================================================= */

const MAX_LINES = 20000;        // 片側でこの行数を超えたら比較しない
const MAX_CELLS = 2000000;      // 計算表のマス目の上限（超えたら比較しない）
const MAX_INLINE_TOKENS = 4000; // 1行の中を細かく比べるときの上限
const MAX_SAVE_CHARS = 100000;  // これを超える文章は保存しない（保存領域を圧迫するため）
const DEBOUNCE_MS = 250;
const TOAST_MS = 1700;
const STORE_KEY = 'diffChecker.state';

const state = {
  unit: 'line',
  ignoreCase: false,
  ignoreTrim: false,
  ignoreBlank: false
};

/* =========================================================
   1. 小さな道具
   ========================================================= */

const $ = (id) => document.getElementById(id);

const el = {
  titlebar:   $('titlebar'),
  btnClose:   $('btnClose'),
  btnHelp:    $('btnHelp'),
  btnSwap:    $('btnSwap'),
  btnClearAll:$('btnClearAll'),
  btnCopy:    $('btnCopyResult'),
  textA:      $('textA'),
  textB:      $('textB'),
  countA:     $('countA'),
  countB:     $('countB'),
  optCase:    $('optCase'),
  optTrim:    $('optTrim'),
  optBlank:   $('optBlank'),
  colA:       $('colA'),
  colB:       $('colB'),
  result:     $('result'),
  resultEmpty:$('resultEmpty'),
  stats:      $('stats'),
  fileInput:  $('fileInput'),
  toast:      $('toast')
};

/** 拡張機能として動いているかどうか */
const hasChromeStorage = (() => {
  try {
    return typeof chrome !== 'undefined' && !!chrome.storage && !!chrome.storage.local;
  } catch (e) {
    return false;
  }
})();

/** 保存（拡張機能なら chrome.storage.local、単体HTMLなら localStorage） */
async function saveState(data) {
  try {
    if (hasChromeStorage) {
      await chrome.storage.local.set({ [STORE_KEY]: data });
    } else {
      localStorage.setItem(STORE_KEY, JSON.stringify(data));
    }
  } catch (e) {
    // 保存に失敗しても比較そのものは続けられるので、黙って見送る
  }
}

async function loadState() {
  try {
    if (hasChromeStorage) {
      const got = await chrome.storage.local.get(STORE_KEY);
      return got[STORE_KEY] || null;
    }
    const raw = localStorage.getItem(STORE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

let toastTimer = null;
function toast(message, isWarn) {
  el.toast.textContent = message;
  el.toast.classList.toggle('is-warn', !!isWarn);
  el.toast.classList.add('is-on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.toast.classList.remove('is-on'), TOAST_MS);
}

function debounce(fn, ms) {
  let t = null;
  return function () {
    clearTimeout(t);
    t = setTimeout(fn, ms);
  };
}

/* ---- 小窓をつまんで動かす ---- */

(function enableWindowDrag() {
  if (!hasChromeStorage || !chrome.windows) return;

  let dragging = false;
  let startScreenX = 0, startScreenY = 0;
  let startLeft = 0, startTop = 0;
  let windowId = null;

  el.titlebar.addEventListener('pointerdown', async (ev) => {
    // ボタンや入力欄の上ではドラッグを始めない
    if (ev.target.closest('button, input, select, textarea, a')) return;
    if (ev.button !== 0) return;

    try {
      const win = await chrome.windows.getCurrent();
      if (!win || win.type !== 'popup') return;   // タブで開かれているときは動かせない
      windowId = win.id;
      startLeft = win.left;
      startTop = win.top;
    } catch (e) {
      return;
    }

    dragging = true;
    startScreenX = ev.screenX;
    startScreenY = ev.screenY;
    el.titlebar.classList.add('is-dragging');
    el.titlebar.setPointerCapture(ev.pointerId);
  });

  el.titlebar.addEventListener('pointermove', (ev) => {
    if (!dragging || windowId === null) return;
    const left = Math.round(startLeft + (ev.screenX - startScreenX));
    const top  = Math.round(startTop  + (ev.screenY - startScreenY));
    chrome.windows.update(windowId, { left, top }).catch(() => {});
  });

  const stop = (ev) => {
    if (!dragging) return;
    dragging = false;
    el.titlebar.classList.remove('is-dragging');
    try { el.titlebar.releasePointerCapture(ev.pointerId); } catch (e) {}
  };
  el.titlebar.addEventListener('pointerup', stop);
  el.titlebar.addEventListener('pointercancel', stop);
})();

el.btnClose.addEventListener('click', async () => {
  try {
    const win = await chrome.windows.getCurrent();
    await chrome.windows.remove(win.id);
  } catch (e) {
    window.close();
  }
});

el.btnHelp.addEventListener('click', () => {
  const url = hasChromeStorage && chrome.runtime
    ? chrome.runtime.getURL('index.html')
    : 'index.html';
  try {
    chrome.tabs.create({ url });
  } catch (e) {
    window.open(url, '_blank');
  }
});

/* =========================================================
   2. 文章を単位に切り分ける
   ========================================================= */

/** 改行の書き方の違い（Windows / Mac）をそろえてから行に分ける */
function splitLines(text) {
  return text.replace(/\r\n?/g, '\n').split('\n');
}

/**
 * 比較用の並びを作る。
 * 画面には元の文字をそのまま出したいので、
 * 「表示用の text」と「くらべる用の key」を別々に持たせる。
 */
function buildLines(text) {
  const raw = splitLines(text);
  const out = [];
  for (let i = 0; i < raw.length; i++) {
    const t = raw[i];
    if (state.ignoreBlank && t.trim() === '') continue;
    let key = t;
    if (state.ignoreTrim) key = key.trim();
    if (state.ignoreCase) key = key.toLowerCase();
    out.push({ text: t, key, no: i + 1 });
  }
  return out;
}

/* 文字の種類を見分けるための表（範囲は \u で書いています） */
const RE_SPACE = /\s/;
const RE_ASCII = /[0-9A-Za-z_\uFF10-\uFF19\uFF21-\uFF3A\uFF41-\uFF5A]/;    // 半角と全角の英数字
const RE_HIRA  = /[\u3041-\u309F]/;                                   // ひらがな
const RE_KATA  = /[\u30A0-\u30FF\uFF66-\uFF9F]/;                       // カタカナ（半角も）
const RE_KANJI = /[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF\u3005\u3006\u30F6]/;  // 漢字と々〆ヶ

/** 文字の種類を返す。単語に切り分けるときの境目に使う */
function charCategory(ch) {
  if (RE_SPACE.test(ch)) return 'space';
  if (RE_ASCII.test(ch)) return 'ascii';
  if (RE_HIRA.test(ch))  return 'hira';
  if (RE_KATA.test(ch))  return 'kata';
  if (RE_KANJI.test(ch)) return 'kanji';
  return 'other';
}

/**
 * 1行を「単語」に切り分ける。
 * 日本語には単語のあいだに空白が無いので、空白だけで切ると
 * 1行がまるごと1語になってしまう。文字の種類が変わる位置でも切る。
 */
function splitWords(line) {
  const chars = Array.from(line);
  const tokens = [];
  let buf = '';
  let cat = null;
  for (const ch of chars) {
    const c = charCategory(ch);
    if (c === 'other') {                 // 記号は1文字ずつ独立させる
      if (buf) tokens.push(buf);
      buf = '';
      cat = null;
      tokens.push(ch);
      continue;
    }
    if (cat === c) {
      buf += ch;
    } else {
      if (buf) tokens.push(buf);
      buf = ch;
      cat = c;
    }
  }
  if (buf) tokens.push(buf);
  return tokens;
}

function splitChars(line) {
  return Array.from(line);
}

/* =========================================================
   3. 差分を求める（LCS）
   ========================================================= */

/**
 * 2つの並びをくらべて、[{ t, ai, bi }] の形で返す。
 *   t = 0 同じ / 1 左にしかない（削除）/ 2 右にしかない（追加）
 *
 * そのまま全体を計算表に載せると重いので、
 * 先に前後の共通部分を切り落として、食い違っている真ん中だけを計算する。
 * 表は Uint32Array に確保する（二次元配列より速く、軽い）。
 *
 * 大きすぎて計算できないときは null を返す。
 */
function lcsDiff(aKeys, bKeys) {
  const n = aKeys.length;
  const m = bKeys.length;

  let head = 0;
  while (head < n && head < m && aKeys[head] === bKeys[head]) head++;

  let tail = 0;
  while (tail < n - head && tail < m - head &&
         aKeys[n - 1 - tail] === bKeys[m - 1 - tail]) tail++;

  const aN = n - head - tail;
  const bN = m - head - tail;

  if ((aN + 1) * (bN + 1) > MAX_CELLS) return null;

  const ops = [];
  for (let i = 0; i < head; i++) ops.push({ t: 0, ai: i, bi: i });

  if (aN > 0 && bN > 0) {
    const w = bN + 1;
    const dp = new Uint32Array((aN + 1) * w);
    for (let i = aN - 1; i >= 0; i--) {
      const ak = aKeys[head + i];
      const rowBase = i * w;
      const nextBase = rowBase + w;
      for (let j = bN - 1; j >= 0; j--) {
        dp[rowBase + j] = (ak === bKeys[head + j])
          ? dp[nextBase + j + 1] + 1
          : Math.max(dp[nextBase + j], dp[rowBase + j + 1]);
      }
    }
    let i = 0, j = 0;
    while (i < aN && j < bN) {
      if (aKeys[head + i] === bKeys[head + j]) {
        ops.push({ t: 0, ai: head + i, bi: head + j });
        i++; j++;
      } else if (dp[(i + 1) * w + j] >= dp[i * w + (j + 1)]) {
        ops.push({ t: 1, ai: head + i, bi: -1 });
        i++;
      } else {
        ops.push({ t: 2, ai: -1, bi: head + j });
        j++;
      }
    }
    while (i < aN) { ops.push({ t: 1, ai: head + i, bi: -1 }); i++; }
    while (j < bN) { ops.push({ t: 2, ai: -1, bi: head + j }); j++; }
  } else {
    for (let i = 0; i < aN; i++) ops.push({ t: 1, ai: head + i, bi: -1 });
    for (let j = 0; j < bN; j++) ops.push({ t: 2, ai: -1, bi: head + j });
  }

  for (let k = 0; k < tail; k++) {
    ops.push({ t: 0, ai: n - tail + k, bi: m - tail + k });
  }
  return ops;
}

/**
 * 差分の並びを「行」にまとめ直す。
 * 消えた行のかたまりのすぐ後ろに増えた行のかたまりが来ていたら、
 * それは「書き換えられた行」として左右で対にする。
 * こうしないと左右の高さがずれて、目でくらべられなくなる。
 */
function pairRows(ops) {
  const rows = [];
  let i = 0;
  while (i < ops.length) {
    if (ops[i].t === 0) {
      rows.push({ kind: 'eq', ai: ops[i].ai, bi: ops[i].bi });
      i++;
      continue;
    }
    const dels = [];
    while (i < ops.length && ops[i].t === 1) { dels.push(ops[i].ai); i++; }
    const adds = [];
    while (i < ops.length && ops[i].t === 2) { adds.push(ops[i].bi); i++; }

    const paired = Math.min(dels.length, adds.length);
    for (let k = 0; k < paired; k++) rows.push({ kind: 'mod', ai: dels[k], bi: adds[k] });
    for (let k = paired; k < dels.length; k++) rows.push({ kind: 'del', ai: dels[k], bi: -1 });
    for (let k = paired; k < adds.length; k++) rows.push({ kind: 'add', ai: -1, bi: adds[k] });
  }
  return rows;
}

/* =========================================================
   4. 画面に描く
   ========================================================= */

/** 1行ぶんの要素を作る。text が null のときは空の場所取り行 */
function makeLine(no, sign, kindClass, pieces) {
  const line = document.createElement('div');
  line.className = 'ln ' + kindClass;
  line.setAttribute('role', 'listitem');

  const noEl = document.createElement('span');
  noEl.className = 'ln__no';
  noEl.textContent = no === null ? '' : String(no);

  const signEl = document.createElement('span');
  signEl.className = 'ln__sign';
  signEl.textContent = sign;

  const textEl = document.createElement('span');
  textEl.className = 'ln__text';
  if (pieces === null) {
    textEl.textContent = '';
  } else if (typeof pieces === 'string') {
    // 入力された文章は必ず textContent で入れる（innerHTML に渡さない）
    textEl.textContent = pieces === '' ? ' ' : pieces;
  } else {
    for (const p of pieces) {
      if (p.mark) {
        const mk = document.createElement('mark');
        mk.className = 'mk ' + p.mark;
        mk.textContent = p.text;
        textEl.appendChild(mk);
      } else {
        textEl.appendChild(document.createTextNode(p.text));
      }
    }
    if (!textEl.textContent) textEl.textContent = ' ';
  }

  line.append(noEl, signEl, textEl);
  return line;
}

/** 書き換えられた行の中を、単語または文字でくらべて塗り分ける */
function inlinePieces(aText, bText) {
  const split = state.unit === 'char' ? splitChars : splitWords;
  const at = split(aText);
  const bt = split(bText);
  if (at.length > MAX_INLINE_TOKENS || bt.length > MAX_INLINE_TOKENS) {
    return { a: aText, b: bText };
  }
  const ops = lcsDiff(at, bt);
  if (!ops) return { a: aText, b: bText };

  const aPieces = [];
  const bPieces = [];
  const push = (arr, text, mark) => {
    const last = arr[arr.length - 1];
    if (last && last.mark === mark) last.text += text;
    else arr.push({ text, mark });
  };
  for (const op of ops) {
    if (op.t === 0) {
      push(aPieces, at[op.ai], null);
      push(bPieces, bt[op.bi], null);
    } else if (op.t === 1) {
      push(aPieces, at[op.ai], 'mk--del');
    } else {
      push(bPieces, bt[op.bi], 'mk--add');
    }
  }
  return { a: aPieces, b: bPieces };
}

function setStats(add, del, mod, rate) {
  el.stats.textContent = '';
  const mk = (cls, text) => {
    const s = document.createElement('span');
    s.className = 'badge ' + cls;
    s.textContent = text;
    return s;
  };
  el.stats.append(
    mk('badge--add', '追加 ' + add + '行'),
    mk('badge--del', '削除 ' + del + '行'),
    mk('badge--mod', '変更 ' + mod + '行'),
    mk('', '一致率 ' + rate)
  );
}

let lastReport = '';

function render() {
  const rawA = el.textA.value;
  const rawB = el.textB.value;

  updateCounts();

  el.colA.textContent = '';
  el.colB.textContent = '';
  el.resultEmpty.classList.remove('is-done');
  lastReport = '';

  if (rawA === '' && rawB === '') {
    el.result.classList.remove('is-filled');
    el.resultEmpty.textContent = '左右に文章を入れると、ここに違いが出ます。ボタンを押す必要はありません';
    setStats(0, 0, 0, '—');
    return;
  }

  const linesA = buildLines(rawA);
  const linesB = buildLines(rawB);

  if (linesA.length > MAX_LINES || linesB.length > MAX_LINES) {
    el.result.classList.remove('is-filled');
    el.resultEmpty.textContent =
      '文章が大きすぎます（片側 ' + MAX_LINES + ' 行までです）。分けてお試しください';
    setStats(0, 0, 0, '—');
    toast('文章が大きすぎます。分けてお試しください', true);
    return;
  }

  const ops = lcsDiff(linesA.map((l) => l.key), linesB.map((l) => l.key));
  if (!ops) {
    el.result.classList.remove('is-filled');
    el.resultEmpty.textContent =
      '違いが多すぎて、この量では比べられません。文章を分けてお試しください';
    setStats(0, 0, 0, '—');
    toast('文章が大きすぎます。行単位でお試しください', true);
    return;
  }

  const rows = pairRows(ops);
  let nAdd = 0, nDel = 0, nMod = 0, nEq = 0;

  const fragA = document.createDocumentFragment();
  const fragB = document.createDocumentFragment();
  const report = [];
  const inline = (state.unit !== 'line');

  for (const row of rows) {
    if (row.kind === 'eq') {
      nEq++;
      const a = linesA[row.ai], b = linesB[row.bi];
      fragA.appendChild(makeLine(a.no, ' ', '', a.text));
      fragB.appendChild(makeLine(b.no, ' ', '', b.text));
      report.push('  ' + a.text);
    } else if (row.kind === 'del') {
      nDel++;
      const a = linesA[row.ai];
      fragA.appendChild(makeLine(a.no, '−', 'ln--del', a.text));
      fragB.appendChild(makeLine(null, '', 'ln--gap', null));
      report.push('- ' + a.text);
    } else if (row.kind === 'add') {
      nAdd++;
      const b = linesB[row.bi];
      fragA.appendChild(makeLine(null, '', 'ln--gap', null));
      fragB.appendChild(makeLine(b.no, '＋', 'ln--add', b.text));
      report.push('+ ' + b.text);
    } else {
      nMod++;
      const a = linesA[row.ai], b = linesB[row.bi];
      let pa = a.text, pb = b.text;
      if (inline) {
        const got = inlinePieces(a.text, b.text);
        pa = got.a; pb = got.b;
      }
      fragA.appendChild(makeLine(a.no, '≠', 'ln--del', pa));
      fragB.appendChild(makeLine(b.no, '≠', 'ln--add', pb));
      report.push('- ' + a.text);
      report.push('+ ' + b.text);
    }
  }

  el.colA.appendChild(fragA);
  el.colB.appendChild(fragB);

  const total = linesA.length + linesB.length;
  const rate = total === 0 ? '—' : Math.round((nEq * 2 * 100) / total) + '%';
  setStats(nAdd, nDel, nMod, rate);

  lastReport = report.join('\n');

  if (nAdd === 0 && nDel === 0 && nMod === 0) {
    el.result.classList.remove('is-filled');
    el.resultEmpty.textContent = '違いは見つかりませんでした';
    el.resultEmpty.classList.add('is-done');
  } else {
    el.result.classList.add('is-filled');
  }
}

const renderSoon = debounce(render, DEBOUNCE_MS);

/* =========================================================
   5. 入力まわり
   ========================================================= */

function countOf(text) {
  const lines = text === '' ? 0 : splitLines(text).length;
  return lines + '行 / ' + Array.from(text).length + '文字';
}

function updateCounts() {
  el.countA.textContent = countOf(el.textA.value);
  el.countB.textContent = countOf(el.textB.value);
}

const saveSoon = debounce(() => {
  const a = el.textA.value;
  const b = el.textB.value;
  saveState({
    unit: state.unit,
    ignoreCase: state.ignoreCase,
    ignoreTrim: state.ignoreTrim,
    ignoreBlank: state.ignoreBlank,
    textA: a.length > MAX_SAVE_CHARS ? '' : a,
    textB: b.length > MAX_SAVE_CHARS ? '' : b
  });
}, 500);

function onInput() {
  updateCounts();
  renderSoon();
  saveSoon();
}

el.textA.addEventListener('input', onInput);
el.textB.addEventListener('input', onInput);

/* ---- テキストファイルの読み込み ---- */

const TEXT_EXT = /\.(txt|md|csv|log|json|tsv|html?|css|js)$/i;
let pickTarget = 'a';

function readTextFile(file, target) {
  if (!TEXT_EXT.test(file.name) && !/^text\//.test(file.type) && file.type !== 'application/json') {
    toast(file.name + ' は文字のファイルとして読めませんでした。.txt などでお試しください', true);
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    const box = target === 'a' ? el.textA : el.textB;
    box.value = String(reader.result || '');
    onInput();
    toast(file.name + ' を読み込みました');
  };
  reader.onerror = () => {
    toast(file.name + ' を読み込めませんでした。ファイルを確認してください', true);
  };
  reader.readAsText(file, 'UTF-8');
}

document.querySelectorAll('[data-pick]').forEach((btn) => {
  btn.addEventListener('click', () => {
    pickTarget = btn.getAttribute('data-pick');
    el.fileInput.value = '';
    el.fileInput.click();
  });
});

el.fileInput.addEventListener('change', () => {
  const file = el.fileInput.files && el.fileInput.files[0];
  if (file) readTextFile(file, pickTarget);
});

[['a', el.textA], ['b', el.textB]].forEach(([side, box]) => {
  box.addEventListener('dragover', (ev) => {
    ev.preventDefault();
    box.classList.add('is-over');
  });
  box.addEventListener('dragleave', () => box.classList.remove('is-over'));
  box.addEventListener('drop', (ev) => {
    ev.preventDefault();
    box.classList.remove('is-over');
    const file = ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0];
    if (file) readTextFile(file, side);
  });
});

/* ---- 設定 ---- */

document.querySelectorAll('input[name="unit"]').forEach((radio) => {
  radio.addEventListener('change', () => {
    if (!radio.checked) return;
    state.unit = radio.value;
    render();
    saveSoon();
  });
});

[[el.optCase, 'ignoreCase'], [el.optTrim, 'ignoreTrim'], [el.optBlank, 'ignoreBlank']]
  .forEach(([box, key]) => {
    box.addEventListener('change', () => {
      state[key] = box.checked;
      render();
      saveSoon();
    });
  });

/* ---- ボタン ---- */

el.btnSwap.addEventListener('click', () => {
  const tmp = el.textA.value;
  el.textA.value = el.textB.value;
  el.textB.value = tmp;
  onInput();
  render();
  toast('左右を入れ替えました');
});

el.btnClearAll.addEventListener('click', () => {
  if (el.textA.value === '' && el.textB.value === '') return;
  // 取り消せない操作なので、ここだけ確認を出す
  if (!window.confirm('左右の文章をすべて消します。よろしいですか？')) return;
  el.textA.value = '';
  el.textB.value = '';
  onInput();
  render();
  toast('消しました');
});

el.btnCopy.addEventListener('click', async () => {
  if (!lastReport) {
    toast('コピーする結果がまだありません。先に文章を入れてください', true);
    return;
  }
  try {
    await navigator.clipboard.writeText(lastReport);
    toast('比較結果をコピーしました');
  } catch (e) {
    toast('コピーできませんでした。結果の文字を選んで Ctrl＋C でコピーしてください', true);
  }
});

/* ---- 左右のスクロールを連動させる ---- */

(function syncScroll() {
  let lock = false;
  const link = (from, to) => {
    from.addEventListener('scroll', () => {
      if (lock) return;
      lock = true;
      to.scrollTop = from.scrollTop;
      requestAnimationFrame(() => { lock = false; });
    });
  };
  link(el.colA, el.colB);
  link(el.colB, el.colA);
})();

/* =========================================================
   6. 起動時：前回の続きを戻す
   ========================================================= */

(async function boot() {
  const saved = await loadState();
  if (saved) {
    if (typeof saved.textA === 'string') el.textA.value = saved.textA;
    if (typeof saved.textB === 'string') el.textB.value = saved.textB;
    if (saved.unit === 'line' || saved.unit === 'word' || saved.unit === 'char') {
      state.unit = saved.unit;
      const radio = document.querySelector('input[name="unit"][value="' + saved.unit + '"]');
      if (radio) radio.checked = true;
    }
    state.ignoreCase  = !!saved.ignoreCase;
    state.ignoreTrim  = !!saved.ignoreTrim;
    state.ignoreBlank = !!saved.ignoreBlank;
    el.optCase.checked  = state.ignoreCase;
    el.optTrim.checked  = state.ignoreTrim;
    el.optBlank.checked = state.ignoreBlank;
  }
  render();
})();
