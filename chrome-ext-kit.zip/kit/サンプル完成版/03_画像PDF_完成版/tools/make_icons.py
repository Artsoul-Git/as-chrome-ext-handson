# -*- coding: utf-8 -*-
"""
画像→PDFメーカー用アイコン生成スクリプト

icons/ フォルダに 16 / 32 / 48 / 128 px の PNG を書き出します。
図案：角を折った白い紙（＝PDF）の中に、山と太陽の絵（＝画像）。

■ 使い方
    1. Python と Pillow が入っていることを確認する
         pip install pillow
    2. このファイルがある tools フォルダで実行する
         python make_icons.py
    3. 一つ上の icons フォルダに 4 枚の PNG が上書き保存される

■ 色や形を変えたいとき
    下の「調整できる値」だけを書き換えれば、全サイズに反映されます。
"""

import os
import sys

try:
    from PIL import Image, ImageDraw
except ImportError:
    sys.exit("Pillow が見つかりません。先に `pip install pillow` を実行してください。")

# ------------------------------------------------------------------
# 調整できる値
# ------------------------------------------------------------------
SIZES = (16, 32, 48, 128)           # 書き出すサイズ
BG_COLOR = (106, 61, 95, 255)       # 外枠（葡萄色）
PAPER_COLOR = (253, 251, 252, 255)  # 紙の色
FOLD_COLOR = (222, 208, 218, 255)   # 折った角の影
PHOTO_COLOR = (106, 61, 95, 255)    # 中の絵（山）
SUN_COLOR = (242, 201, 160, 255)    # 中の絵（太陽）
SS = 8                              # 内部で何倍に拡大して描くか（大きいほど滑らか）

CORNER = 0.235                      # 外枠の角丸
MARGIN = 0.045                      # 外周の余白
PAPER_X = 0.215                     # 紙の左右の余白
PAPER_Y = 0.150                     # 紙の上下の余白
PAPER_R = 0.055                     # 紙の角丸
FOLD = 0.230                        # 折った角の大きさ（紙の幅に対する比率）
# ------------------------------------------------------------------


def draw_icon(side):
    """1辺 side ピクセルのアイコンを描いて返す（あとで縮小する前提の大きさ）。"""
    img = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # 外枠
    m = side * MARGIN
    d.rounded_rectangle([m, m, side - m, side - m],
                        radius=side * CORNER, fill=BG_COLOR)

    # 白い紙
    px, py = side * PAPER_X, side * PAPER_Y
    left, top, right, bottom = px, py, side - px, side - py
    d.rounded_rectangle([left, top, right, bottom],
                        radius=side * PAPER_R, fill=PAPER_COLOR)

    # 右上の角を折る
    fold = (right - left) * FOLD
    d.polygon([(right - fold, top), (right, top), (right, top + fold)], fill=BG_COLOR)
    d.polygon([(right - fold, top), (right, top + fold), (right - fold, top + fold)],
              fill=FOLD_COLOR)

    # 中の絵：太陽
    w = right - left
    h = bottom - top
    sun_r = w * 0.10
    sun_cx = left + w * 0.32
    sun_cy = top + h * 0.42
    d.ellipse([sun_cx - sun_r, sun_cy - sun_r, sun_cx + sun_r, sun_cy + sun_r], fill=SUN_COLOR)

    # 中の絵：山（2つ重ねる）
    base = bottom - h * 0.22
    d.polygon([(left + w * 0.16, base),
               (left + w * 0.44, base - h * 0.30),
               (left + w * 0.72, base)], fill=PHOTO_COLOR)
    d.polygon([(left + w * 0.48, base),
               (left + w * 0.70, base - h * 0.20),
               (left + w * 0.92, base)], fill=PHOTO_COLOR)

    # 紙の下の1本線（書類らしさ）
    ly = bottom - h * 0.13
    lt = h * 0.035
    d.rounded_rectangle([left + w * 0.16, ly - lt, left + w * 0.84, ly + lt],
                        radius=lt, fill=FOLD_COLOR)

    return img


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    out_dir = os.path.join(os.path.dirname(here), "icons")
    os.makedirs(out_dir, exist_ok=True)

    for size in SIZES:
        big = draw_icon(size * SS)
        small = big.resize((size, size), Image.LANCZOS)
        path = os.path.join(out_dir, "icon{}.png".format(size))
        small.save(path, "PNG")
        print("書き出しました:", path)


if __name__ == "__main__":
    main()
