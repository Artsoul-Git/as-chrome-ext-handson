/*
 * app.js — 画像→PDFメーカー 本体
 *
 * 中身は大きく4つに分かれています。
 *   1. 小さな道具（保存・トースト・小窓の移動）
 *   2. 画像を読み込んで並べる
 *   3. PDFのバイト列を自分で組み立てる
 *   4. 保存する
 *
 * 外部ライブラリは使っていません。PDFの組み立ても自前です。
 * PDFは JPEG 画像をそのままの形で中に入れられる決まりになっているので、
 * 画像を圧縮し直す仕組みを自分で書かずに済みます。
 */

'use strict';

/* =========================================================
   0. 定数と状態
   ========================================================= */

const MAX_PAGES = 50;          // 並べられる枚数の上限
const MAX_EDGE = 8192;         // 1枚の縦横の上限（画素）
const THUMB_EDGE = 320;        // サムネイルの長辺
const TOAST_MS = 1700;
const STORE_KEY = 'imgToPdf.settings';

const MM = 72 / 25.4;          // 1ミリは何ポイントか
const A4_W = 595.28;           // A4 の短い辺（ポイント）
const A4_H = 841.89;           // A4 の長い辺（ポイント）
const PX_TO_PT = 0.75;         // 画面の1画素は0.75ポイント（96dpi 換算）

let items = [];                // 並んでいるページ
let nextId = 1;
let busy = false;

/* =========================================================
   1. 小さな道具
   ========================================================= */

const $ = (id) => document.getElementById(id);

const el = {
  titlebar:   $('titlebar'),
  btnClose:   $('btnClose'),
  btnHelp:    $('btnHelp'),
  dropzone:   $('dropzone'),
  fileInput:  $('fileInput'),
  pages:      $('pages'),
  pagesEmpty: $('pagesEmpty'),
  countBadge: $('countBadge'),
  btnClearAll:$('btnClearAll'),
  selSize:    $('selSize'),
  selMargin:  $('selMargin'),
  selQuality: $('selQuality'),
  fileName:   $('fileName'),
  btnMake:    $('btnMake'),
  progress:   $('progress'),
  toast:      $('toast')
};

const hasChromeStorage = (() => {
  try {
    return typeof chrome !== 'undefined' && !!chrome.storage && !!chrome.storage.local;
  } catch (e) {
    return false;
  }
})();

async function saveSettings() {
  const data = {
    size: el.selSize.value,
    margin: el.selMargin.value,
    quality: el.selQuality.value,
    fileName: el.fileName.value
  };
  try {
    if (hasChromeStorage) await chrome.storage.local.set({ [STORE_KEY]: data });
    else localStorage.setItem(STORE_KEY, JSON.stringify(data));
  } catch (e) {
    // 保存に失敗してもPDF作りには影響しないので、黙って見送る
  }
}

async function loadSettings() {
  try {
    if (hasChromeStorage) {
      const got = await chrome.storage.local.get(STORE_KEY);
      return got[STORE_KEY] || null;
    }
    const raw = localStorage.getItem(STORE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

let toastTimer = null;
function toast(message, isWarn) {
  el.toast.textContent = message;
  el.toast.classList.toggle('is-warn', !!isWarn);
  el.toast.classList.add('is-on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.toast.classList.remove('is-on'), TOAST_MS);
}

/** 画面を一度描き直させて、処理中に固まって見えないようにする */
function breathe() {
  return new Promise((resolve) => requestAnimationFrame(() => setTimeout(resolve, 0)));
}

/* ---- 小窓をつまんで動かす ---- */

(function enableWindowDrag() {
  if (!hasChromeStorage || !chrome.windows) return;

  let dragging = false;
  let startScreenX = 0, startScreenY = 0;
  let startLeft = 0, startTop = 0;
  let windowId = null;

  el.titlebar.addEventListener('pointerdown', async (ev) => {
    // ボタンや入力欄の上ではドラッグを始めない
    if (ev.target.closest('button, input, select, textarea, a')) return;
    if (ev.button !== 0) return;

    try {
      const win = await chrome.windows.getCurrent();
      if (!win || win.type !== 'popup') return;   // タブで開かれているときは動かせない
      windowId = win.id;
      startLeft = win.left;
      startTop = win.top;
    } catch (e) {
      return;
    }

    dragging = true;
    startScreenX = ev.screenX;
    startScreenY = ev.screenY;
    el.titlebar.classList.add('is-dragging');
    el.titlebar.setPointerCapture(ev.pointerId);
  });

  el.titlebar.addEventListener('pointermove', (ev) => {
    if (!dragging || windowId === null) return;
    const left = Math.round(startLeft + (ev.screenX - startScreenX));
    const top  = Math.round(startTop  + (ev.screenY - startScreenY));
    chrome.windows.update(windowId, { left, top }).catch(() => {});
  });

  const stop = (ev) => {
    if (!dragging) return;
    dragging = false;
    el.titlebar.classList.remove('is-dragging');
    try { el.titlebar.releasePointerCapture(ev.pointerId); } catch (e) {}
  };
  el.titlebar.addEventListener('pointerup', stop);
  el.titlebar.addEventListener('pointercancel', stop);
})();

el.btnClose.addEventListener('click', async () => {
  try {
    const win = await chrome.windows.getCurrent();
    await chrome.windows.remove(win.id);
  } catch (e) {
    window.close();
  }
});

el.btnHelp.addEventListener('click', () => {
  const url = hasChromeStorage && chrome.runtime
    ? chrome.runtime.getURL('index.html')
    : 'index.html';
  try {
    chrome.tabs.create({ url });
  } catch (e) {
    window.open(url, '_blank');
  }
});

/* =========================================================
   2. 画像を読み込んで並べる
   ========================================================= */

const IMAGE_EXT = /\.(png|jpe?g|webp|gif|bmp)$/i;

/** 回転を考えたときの、実際の縦横 */
function effSize(item) {
  const swap = (item.rot % 180) === 90;
  return { w: swap ? item.h : item.w, h: swap ? item.w : item.h };
}

/** 1枚を canvas に描く（回転と、透過を白で埋める処理をここで済ませる） */
function drawToCanvas(item, targetW, targetH) {
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(targetW));
  canvas.height = Math.max(1, Math.round(targetH));
  const ctx = canvas.getContext('2d');

  // 透過のある画像が黒くつぶれないよう、先に白で塗る
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  const eff = effSize(item);
  const scale = Math.min(canvas.width / eff.w, canvas.height / eff.h);

  ctx.save();
  ctx.translate(canvas.width / 2, canvas.height / 2);
  ctx.rotate((item.rot * Math.PI) / 180);
  ctx.scale(scale, scale);
  ctx.drawImage(item.bitmap, -item.w / 2, -item.h / 2, item.w, item.h);
  ctx.restore();

  return canvas;
}

/** 一覧に出す小さな絵を作っておく（元の絵を50枚並べると重いため） */
function makeThumb(item) {
  const eff = effSize(item);
  const scale = Math.min(1, THUMB_EDGE / Math.max(eff.w, eff.h));
  const canvas = drawToCanvas(item, eff.w * scale, eff.h * scale);
  return canvas.toDataURL('image/jpeg', 0.8);
}

async function addFiles(fileList) {
  const files = Array.from(fileList || []).filter(
    (f) => f && (/^image\//.test(f.type) || IMAGE_EXT.test(f.name))
  );

  if (files.length === 0) {
    toast('画像として読めるファイルがありませんでした。PNG や JPEG でお試しください', true);
    return;
  }

  let added = 0;
  let overflow = false;

  for (const file of files) {
    if (items.length >= MAX_PAGES) { overflow = true; break; }
    let bitmap = null;
    try {
      bitmap = await createImageBitmap(file);
    } catch (e) {
      toast(file.name + ' は画像として読めませんでした。別の形式でお試しください', true);
      continue;
    }
    if (bitmap.width > MAX_EDGE || bitmap.height > MAX_EDGE) {
      bitmap.close();
      toast(file.name + ' は大きすぎます（縦横 ' + MAX_EDGE + ' 画素まで）。縮めてからお試しください', true);
      continue;
    }
    const item = {
      id: nextId++,
      name: file.name || ('画像' + nextId),
      bitmap,
      w: bitmap.width,
      h: bitmap.height,
      rot: 0,
      thumb: ''
    };
    item.thumb = makeThumb(item);
    items.push(item);
    added++;
  }

  renderPages();

  if (overflow) {
    toast('一度に並べられるのは ' + MAX_PAGES + ' 枚までです。先にPDFを作ってから続けてください', true);
  } else if (added > 0) {
    toast(added + '枚を追加しました');
  }
}

function removeItem(id) {
  const i = items.findIndex((x) => x.id === id);
  if (i < 0) return;
  try { items[i].bitmap.close(); } catch (e) {}
  items.splice(i, 1);
  renderPages();
}

function moveItem(id, delta) {
  const i = items.findIndex((x) => x.id === id);
  const j = i + delta;
  if (i < 0 || j < 0 || j >= items.length) return;
  const tmp = items[i];
  items[i] = items[j];
  items[j] = tmp;
  renderPages();
}

function rotateItem(id) {
  const item = items.find((x) => x.id === id);
  if (!item) return;
  item.rot = (item.rot + 90) % 360;
  item.thumb = makeThumb(item);
  renderPages();
}

function renderPages() {
  el.pages.textContent = '';
  el.countBadge.textContent = items.length + '枚';
  el.btnMake.disabled = busy || items.length === 0;
  el.pagesEmpty.classList.toggle('is-hidden', items.length > 0);

  const frag = document.createDocumentFragment();

  items.forEach((item, index) => {
    const eff = effSize(item);

    const card = document.createElement('div');
    card.className = 'card';
    card.setAttribute('role', 'listitem');

    const thumb = document.createElement('div');
    thumb.className = 'card__thumb';

    const img = document.createElement('img');
    img.src = item.thumb;
    img.alt = (index + 1) + '枚目：' + item.name;

    const no = document.createElement('span');
    no.className = 'card__no';
    no.textContent = String(index + 1);

    thumb.append(img, no);

    const meta = document.createElement('div');
    meta.className = 'card__meta';
    const name = document.createElement('p');
    name.className = 'card__name';
    name.textContent = item.name;
    name.title = item.name;
    const size = document.createElement('p');
    size.className = 'card__size';
    size.textContent = eff.w + ' × ' + eff.h;
    meta.append(name, size);

    const tools = document.createElement('div');
    tools.className = 'card__tools';

    const mk = (label, aria, cls, disabled, onClick) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'cbtn' + (cls ? ' ' + cls : '');
      b.textContent = label;
      b.setAttribute('aria-label', aria);
      b.title = aria;
      b.disabled = !!disabled;
      b.addEventListener('click', onClick);
      return b;
    };

    tools.append(
      mk('←', (index + 1) + '枚目を1つ前へ移動', '', index === 0,
        () => moveItem(item.id, -1)),
      mk('→', (index + 1) + '枚目を1つ後ろへ移動', '', index === items.length - 1,
        () => moveItem(item.id, 1)),
      mk('⟳', (index + 1) + '枚目を90度回転', '', false,
        () => rotateItem(item.id)),
      mk('✕', (index + 1) + '枚目を削除', 'cbtn--del', false,
        () => removeItem(item.id))
    );

    card.append(thumb, meta, tools);
    frag.appendChild(card);
  });

  el.pages.appendChild(frag);
}

/* ---- 読み込みの入口 ---- */

el.dropzone.addEventListener('click', () => {
  el.fileInput.value = '';
  el.fileInput.click();
});
el.dropzone.addEventListener('keydown', (ev) => {
  if (ev.key === 'Enter' || ev.key === ' ') {
    ev.preventDefault();
    el.dropzone.click();
  }
});
el.fileInput.addEventListener('change', () => {
  if (el.fileInput.files && el.fileInput.files.length) addFiles(el.fileInput.files);
});

['dragenter', 'dragover'].forEach((type) => {
  el.dropzone.addEventListener(type, (ev) => {
    ev.preventDefault();
    el.dropzone.classList.add('is-over');
  });
});
['dragleave', 'dragend'].forEach((type) => {
  el.dropzone.addEventListener(type, () => el.dropzone.classList.remove('is-over'));
});
el.dropzone.addEventListener('drop', (ev) => {
  ev.preventDefault();
  el.dropzone.classList.remove('is-over');
  if (ev.dataTransfer && ev.dataTransfer.files) addFiles(ev.dataTransfer.files);
});

// 画面のどこにドラッグしても、ブラウザが画像を開いてしまわないようにする
['dragover', 'drop'].forEach((type) => {
  document.addEventListener(type, (ev) => {
    if (!el.dropzone.contains(ev.target)) ev.preventDefault();
  });
});

document.addEventListener('paste', (ev) => {
  const files = ev.clipboardData && ev.clipboardData.files;
  if (files && files.length) {
    ev.preventDefault();
    addFiles(files);
  }
});

el.btnClearAll.addEventListener('click', () => {
  if (items.length === 0) return;
  // 取り消せない操作なので、ここだけ確認を出す
  if (!window.confirm('並んでいる ' + items.length + ' 枚をすべて消します。よろしいですか？')) return;
  for (const item of items) { try { item.bitmap.close(); } catch (e) {} }
  items = [];
  renderPages();
  el.progress.textContent = '';
  el.progress.classList.remove('is-done');
  toast('すべて消しました');
});

/* =========================================================
   3. PDFのバイト列を自分で組み立てる
   ========================================================= */

/** ページの大きさと、その中のどこに画像を置くかを決める */
function layout(w, h, sizeMode, marginMm) {
  if (sizeMode === 'fit') {
    const pageW = w * PX_TO_PT;
    const pageH = h * PX_TO_PT;
    return { pageW, pageH, drawW: pageW, drawH: pageH, dx: 0, dy: 0 };
  }
  const pageW = sizeMode === 'a4l' ? A4_H : A4_W;
  const pageH = sizeMode === 'a4l' ? A4_W : A4_H;
  const m = marginMm * MM;
  const availW = Math.max(1, pageW - m * 2);
  const availH = Math.max(1, pageH - m * 2);
  const scale = Math.min(availW / w, availH / h);
  const drawW = w * scale;
  const drawH = h * scale;
  return { pageW, pageH, drawW, drawH, dx: (pageW - drawW) / 2, dy: (pageH - drawH) / 2 };
}

const f2 = (n) => (Math.round(n * 100) / 100).toFixed(2);

/**
 * PDF を組み立てる。
 * pages の各要素は { jpeg, w, h, pageW, pageH, drawW, drawH, dx, dy }。
 *
 * 中身の順番：
 *   ヘッダ → カタログ(1) → ページの木(2) →
 *   1ページごとに ページ本体 / 内容 / 画像 の3つ →
 *   相互参照表(xref) → トレーラ → %%EOF
 * 各オブジェクトが何バイト目から始まるかを控えながら書き、最後に相互参照表へ並べる。
 */
function buildPdf(pages) {
  const encoder = new TextEncoder();
  const chunks = [];
  let size = 0;

  const put = (x) => {
    const bytes = (typeof x === 'string') ? encoder.encode(x) : x;
    chunks.push(bytes);
    size += bytes.length;
  };

  const offsets = [];
  const startObj = (n) => { offsets[n] = size; put(n + ' 0 obj\n'); };
  const endObj = () => put('endobj\n');

  put('%PDF-1.4\n');
  put(new Uint8Array([0x25, 0xE2, 0xE3, 0xCF, 0xD3, 0x0A])); // 中に画像が入っている合図

  const n = pages.length;
  const kids = [];
  for (let i = 0; i < n; i++) kids.push((3 + i * 3) + ' 0 R');

  startObj(1);
  put('<< /Type /Catalog /Pages 2 0 R >>\n');
  endObj();

  startObj(2);
  put('<< /Type /Pages /Kids [' + kids.join(' ') + '] /Count ' + n + ' >>\n');
  endObj();

  for (let i = 0; i < n; i++) {
    const p = pages[i];
    const pageNo = 3 + i * 3;
    const contentNo = pageNo + 1;
    const imageNo = pageNo + 2;

    startObj(pageNo);
    put('<< /Type /Page /Parent 2 0 R'
      + ' /MediaBox [0 0 ' + f2(p.pageW) + ' ' + f2(p.pageH) + ']'
      + ' /Resources << /XObject << /Im0 ' + imageNo + ' 0 R >> /ProcSet [/PDF /ImageC] >>'
      + ' /Contents ' + contentNo + ' 0 R >>\n');
    endObj();

    // 画像をどこに、どの大きさで置くかを書いた行（cm ＝ 座標の変換）
    const streamText = 'q ' + f2(p.drawW) + ' 0 0 ' + f2(p.drawH)
      + ' ' + f2(p.dx) + ' ' + f2(p.dy) + ' cm /Im0 Do Q\n';
    const streamBytes = encoder.encode(streamText);
    startObj(contentNo);
    put('<< /Length ' + streamBytes.length + ' >>\nstream\n');
    put(streamBytes);
    put('endstream\n');
    endObj();

    startObj(imageNo);
    put('<< /Type /XObject /Subtype /Image'
      + ' /Width ' + p.w + ' /Height ' + p.h
      + ' /ColorSpace /DeviceRGB /BitsPerComponent 8'
      + ' /Filter /DCTDecode /Length ' + p.jpeg.length + ' >>\nstream\n');
    put(p.jpeg);
    put('\nendstream\n');
    endObj();
  }

  const total = 2 + n * 3 + 1;   // 0番も数に入れる
  const xrefStart = size;
  put('xref\n0 ' + total + '\n');
  put('0000000000 65535 f \n');
  for (let no = 1; no < total; no++) {
    put(String(offsets[no]).padStart(10, '0') + ' 00000 n \n');
  }
  put('trailer\n<< /Size ' + total + ' /Root 1 0 R >>\nstartxref\n' + xrefStart + '\n%%EOF\n');

  const out = new Uint8Array(size);
  let pos = 0;
  for (const chunk of chunks) { out.set(chunk, pos); pos += chunk.length; }
  return out;
}

/** 1枚を JPEG のバイト列にする */
async function toJpegBytes(item, quality) {
  const eff = effSize(item);
  const canvas = drawToCanvas(item, eff.w, eff.h);
  const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', quality));
  if (!blob) throw new Error('jpeg');
  const buffer = await blob.arrayBuffer();
  return { bytes: new Uint8Array(buffer), w: canvas.width, h: canvas.height };
}

/* =========================================================
   4. 保存する
   ========================================================= */

function tidyFileName(raw) {
  let name = (raw || '').trim();
  if (name === '') name = 'まとめ.pdf';
  name = name.replace(/[\\/:*?"<>|]/g, '_');   // ファイル名に使えない文字を置き換える
  if (!/\.pdf$/i.test(name)) name += '.pdf';
  return name;
}

el.btnMake.addEventListener('click', async () => {
  if (busy || items.length === 0) return;

  busy = true;
  el.btnMake.disabled = true;
  el.progress.classList.remove('is-done');

  const sizeMode = el.selSize.value;
  const marginMm = Number(el.selMargin.value) || 0;
  const quality = Number(el.selQuality.value) || 0.82;

  try {
    const built = [];
    for (let i = 0; i < items.length; i++) {
      el.progress.textContent = (i + 1) + '枚目 / ' + items.length + '枚中';
      await breathe();   // 画面を固まらせないよう、1枚ごとに描き直しへ戻す

      const jpeg = await toJpegBytes(items[i], quality);
      const box = layout(jpeg.w, jpeg.h, sizeMode, marginMm);
      built.push({ jpeg: jpeg.bytes, w: jpeg.w, h: jpeg.h, ...box });
    }

    el.progress.textContent = 'PDFにまとめています…';
    await breathe();

    const bytes = buildPdf(built);
    const blob = new Blob([bytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const name = tidyFileName(el.fileName.value);
    el.fileName.value = name;

    // chrome.downloads は使わない。a要素で保存できるので権限を1つ減らせる
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);

    const mb = (blob.size / (1024 * 1024)).toFixed(2);
    el.progress.textContent = 'できあがり（' + items.length + 'ページ / ' + mb + ' MB）';
    el.progress.classList.add('is-done');
    toast('PDFを保存しました');
    saveSettings();
  } catch (e) {
    el.progress.textContent = '';
    toast('PDFを作れませんでした。枚数を減らすか、画質を下げてお試しください', true);
  } finally {
    busy = false;
    el.btnMake.disabled = items.length === 0;
  }
});

/* ---- 設定の変更を覚える ---- */

[el.selSize, el.selMargin, el.selQuality].forEach((box) => {
  box.addEventListener('change', () => {
    // 「画像に合わせる」のときは余白を選べないようにする
    el.selMargin.disabled = (el.selSize.value === 'fit');
    saveSettings();
  });
});
el.fileName.addEventListener('change', saveSettings);

/* =========================================================
   5. 起動時：前回の設定を戻す
   ========================================================= */

(async function boot() {
  const saved = await loadSettings();
  if (saved) {
    if (saved.size)    el.selSize.value = saved.size;
    if (saved.margin)  el.selMargin.value = saved.margin;
    if (saved.quality) el.selQuality.value = saved.quality;
    if (saved.fileName) el.fileName.value = saved.fileName;
  }
  el.selMargin.disabled = (el.selSize.value === 'fit');
  renderPages();
})();
