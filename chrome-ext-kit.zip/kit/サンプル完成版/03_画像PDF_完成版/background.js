/*
 * background.js
 * ツールバーのアイコンが押されたときに、独立した小窓を開く担当。
 *
 * manifest の action に default_popup を書いていないため、
 * アイコンのクリックは chrome.action.onClicked でここに届く。
 */

'use strict';

const WINDOW_WIDTH = 860;
const WINDOW_HEIGHT = 880;
const OPEN_WINDOW_KEY = 'openWindowId';

/**
 * 小窓のIDを覚えておくための入れ物。
 * サービスワーカーは使われていないと一度停止するので、
 * 変数だけに覚えさせると忘れてしまう。chrome.storage.session に控えておく。
 */
async function rememberWindowId(id) {
  try {
    await chrome.storage.session.set({ [OPEN_WINDOW_KEY]: id });
  } catch (e) {
    // session が使えない古い環境では覚えないだけ（動作には影響しない）
  }
}

async function recallWindowId() {
  try {
    const saved = await chrome.storage.session.get(OPEN_WINDOW_KEY);
    return typeof saved[OPEN_WINDOW_KEY] === 'number' ? saved[OPEN_WINDOW_KEY] : null;
  } catch (e) {
    return null;
  }
}

chrome.action.onClicked.addListener(async () => {
  // すでに開いていれば、二重に開かず手前に出すだけにする
  const knownId = await recallWindowId();
  if (knownId !== null) {
    try {
      await chrome.windows.get(knownId);
      await chrome.windows.update(knownId, { focused: true });
      return;
    } catch (e) {
      // すでに閉じられていた場合はここに来る。そのまま新規作成へ進む
      await rememberWindowId(null);
    }
  }

  try {
    const created = await chrome.windows.create({
      url: chrome.runtime.getURL('popup.html'),
      type: 'popup',
      width: WINDOW_WIDTH,
      height: WINDOW_HEIGHT,
      focused: true
    });
    await rememberWindowId(created.id);
  } catch (e) {
    // 小窓を作れないほど特殊な状態のときは、通常のタブで開いて逃がす
    await chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') });
  }
});

// 小窓が閉じられたら、覚えていたIDを消す
chrome.windows.onRemoved.addListener(async (closedId) => {
  const knownId = await recallWindowId();
  if (knownId === closedId) {
    await rememberWindowId(null);
  }
});
