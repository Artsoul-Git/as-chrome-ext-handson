/*
 * app.js — カラーピッカーの動き
 *
 * 大きく6つに分かれています。
 *   1. 小道具（トースト・保存）
 *   2. 色の計算（HEX / RGB / HSV / HSL / CMYK の変換）
 *   3. 画面の書き換え（全部の表示を1か所で揃える）
 *   4. 上段：画像パネル
 *   5. 下段：カラーミキサー
 *   6. 小窓の操作（移動・閉じる・画面から色を取る）
 */

'use strict';

/* ==================================================================
   0. 下ごしらえ
   ================================================================== */

const $ = (id) => document.getElementById(id);
const clamp = (n, lo, hi) => (n < lo ? lo : n > hi ? hi : n);

// 拡張機能として動いているか、ただのHTMLファイルとして開かれたかを見分ける
const inExtension = typeof chrome !== 'undefined' && !!chrome.runtime && !!chrome.runtime.id;
const canUseChromeStorage = inExtension && !!chrome.storage && !!chrome.storage.local;
const canUseChromeWindows = inExtension && !!chrome.windows;

const PALETTE_MAX = 16;
const PALETTE_KEY = 'palette';
const TOAST_MS = 1700;
const MAX_IMAGE_SIDE = 8192;

// 画面の部品
const titlebar     = $('titlebar');
const btnEyeDrop   = $('btnEyeDropper');
const btnHelp      = $('btnHelp');
const btnClose     = $('btnClose');

const dropzone     = $('dropzone');
const viewCanvas   = $('viewCanvas');
const emptyHint    = $('emptyHint');
const imageSizeEl  = $('imageSize');
const urlInput     = $('urlInput');
const btnLoad      = $('btnLoad');
const btnClear     = $('btnClear');
const coordText    = $('coordText');
const fileInput    = $('fileInput');
const loupe        = $('loupe');
const loupeCanvas  = $('loupeCanvas');

const svCanvas     = $('svCanvas');
const svCursor     = $('svCursor');
const hueRange     = $('hueRange');
const swatch       = $('swatch');
const swatchLabel  = $('swatchLabel');
const hexInput     = $('hexInput');
const rInput       = $('rInput');
const gInput       = $('gInput');
const bInput       = $('bInput');
const valHex       = $('valHex');
const valRgb       = $('valRgb');
const valHsv       = $('valHsv');
const valHsl       = $('valHsl');
const valCmyk      = $('valCmyk');
const paletteList  = $('paletteList');
const paletteEmpty = $('paletteEmpty');
const btnResetPal  = $('btnResetPalette');
const btnCopyHex   = $('btnCopyHex');
const toastEl      = $('toast');

// 元画像を原寸で持っておく板（色はここから抜き取る）
const srcCanvas = document.createElement('canvas');
const srcCtx    = srcCanvas.getContext('2d', { willReadFrequently: true });
const viewCtx   = viewCanvas.getContext('2d');
const loupeCtx  = loupeCanvas.getContext('2d');
const svCtx     = svCanvas.getContext('2d');

// いまの状態
const state = {
  r: 37, g: 99, b: 235,
  h: 221, s: 0.84, v: 0.92,
  palette: []
};

let hasImage = false;
let layout = null;   // 画像を表示するときの位置と縮小率
let marker = null;   // クリックした点（元画像の座標）
let lastHue = null;  // 色あいが変わったときだけ塗り直すための控え

/* ==================================================================
   1. 小道具（トースト・保存）
   ================================================================== */

let toastTimer = 0;

/** 画面下に短いお知らせを出す（約1.7秒で自動的に消える） */
function toast(message, kind) {
  toastEl.textContent = message;
  toastEl.classList.toggle('is-warn', kind === 'warn');
  toastEl.classList.add('is-on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('is-on'), TOAST_MS);
}

/**
 * 保存の読み書き。
 * 拡張機能なら chrome.storage.local、ただのHTMLとして開かれたときは localStorage。
 */
async function storeGet(key, fallback) {
  if (canUseChromeStorage) {
    try {
      const got = await chrome.storage.local.get(key);
      if (got && got[key] !== undefined) return got[key];
      return fallback;
    } catch (e) { /* 読めなければ下の localStorage へ */ }
  }
  try {
    const raw = localStorage.getItem('colorpicker.' + key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch (e) {
    return fallback;
  }
}

async function storeSet(key, value) {
  if (canUseChromeStorage) {
    try {
      await chrome.storage.local.set({ [key]: value });
      return;
    } catch (e) { /* 書けなければ下の localStorage へ */ }
  }
  try {
    localStorage.setItem('colorpicker.' + key, JSON.stringify(value));
  } catch (e) { /* 保存できない環境では、その回かぎりの表示になる */ }
}

/* ==================================================================
   2. 色の計算
   ================================================================== */

/** "#abc" や "#aabbcc" を {r,g,b} に。読めなければ null */
function hexToRgb(text) {
  if (typeof text !== 'string') return null;
  let v = text.trim().replace(/^#/, '');
  if (/^[0-9a-fA-F]{3}$/.test(v)) v = v[0] + v[0] + v[1] + v[1] + v[2] + v[2];
  if (!/^[0-9a-fA-F]{6}$/.test(v)) return null;
  return {
    r: parseInt(v.slice(0, 2), 16),
    g: parseInt(v.slice(2, 4), 16),
    b: parseInt(v.slice(4, 6), 16)
  };
}

function rgbToHex(r, g, b) {
  const two = (n) => clamp(Math.round(n), 0, 255).toString(16).padStart(2, '0');
  return '#' + two(r) + two(g) + two(b);
}

/** RGB → HSV（h は 0〜360、s と v は 0〜1） */
function rgbToHsv(r, g, b) {
  const rr = r / 255, gg = g / 255, bb = b / 255;
  const max = Math.max(rr, gg, bb);
  const min = Math.min(rr, gg, bb);
  const d = max - min;
  let h = 0;
  if (d !== 0) {
    if (max === rr)      h = 60 * (((gg - bb) / d) % 6);
    else if (max === gg) h = 60 * (((bb - rr) / d) + 2);
    else                 h = 60 * (((rr - gg) / d) + 4);
  }
  if (h < 0) h += 360;
  return { h, s: max === 0 ? 0 : d / max, v: max };
}

/** HSV → RGB（0〜255 の整数） */
function hsvToRgb(h, s, v) {
  const hh = ((h % 360) + 360) % 360;
  const c = v * s;
  const x = c * (1 - Math.abs(((hh / 60) % 2) - 1));
  const m = v - c;
  let rr = 0, gg = 0, bb = 0;
  if (hh < 60)       { rr = c; gg = x; }
  else if (hh < 120) { rr = x; gg = c; }
  else if (hh < 180) { gg = c; bb = x; }
  else if (hh < 240) { gg = x; bb = c; }
  else if (hh < 300) { rr = x; bb = c; }
  else               { rr = c; bb = x; }
  return {
    r: Math.round((rr + m) * 255),
    g: Math.round((gg + m) * 255),
    b: Math.round((bb + m) * 255)
  };
}

/** RGB → HSL（h は 0〜360、s と l は 0〜1） */
function rgbToHsl(r, g, b) {
  const rr = r / 255, gg = g / 255, bb = b / 255;
  const max = Math.max(rr, gg, bb);
  const min = Math.min(rr, gg, bb);
  const d = max - min;
  const l = (max + min) / 2;
  let h = 0;
  if (d !== 0) {
    if (max === rr)      h = 60 * (((gg - bb) / d) % 6);
    else if (max === gg) h = 60 * (((bb - rr) / d) + 2);
    else                 h = 60 * (((rr - gg) / d) + 4);
  }
  if (h < 0) h += 360;
  const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
  return { h, s, l };
}

/** RGB → CMYK（すべて 0〜1） */
function rgbToCmyk(r, g, b) {
  const rr = r / 255, gg = g / 255, bb = b / 255;
  const k = 1 - Math.max(rr, gg, bb);
  if (k === 1) return { c: 0, m: 0, y: 0, k: 1 };
  return {
    c: (1 - rr - k) / (1 - k),
    m: (1 - gg - k) / (1 - k),
    y: (1 - bb - k) / (1 - k),
    k
  };
}

const pct = (n) => Math.round(n * 100) + '%';
const hexOf = () => rgbToHex(state.r, state.g, state.b);

/* ==================================================================
   3. 画面の書き換え
   ================================================================== */

/** 入力欄は「いま入力中のもの」だけ書き換えない（打っている途中を邪魔しないため） */
function setFieldValue(el, value) {
  if (document.activeElement !== el) el.value = value;
}

function render() {
  const hex = hexOf();
  const hsl = rgbToHsl(state.r, state.g, state.b);
  const cmyk = rgbToCmyk(state.r, state.g, state.b);

  // 色見本
  swatch.style.background = hex;
  swatchLabel.textContent = hex;
  const brightness = 0.2126 * state.r + 0.7152 * state.g + 0.0722 * state.b;
  swatchLabel.style.color = brightness > 150 ? '#24302e' : '#ffffff';

  // 入力欄
  setFieldValue(hexInput, hex);
  setFieldValue(rInput, String(state.r));
  setFieldValue(gInput, String(state.g));
  setFieldValue(bInput, String(state.b));
  setFieldValue(hueRange, String(Math.round(state.h)));

  // 5形式の表示
  valHex.textContent  = hex;
  valRgb.textContent  = `rgb(${state.r}, ${state.g}, ${state.b})`;
  valHsv.textContent  = `${Math.round(state.h)}deg, ${pct(state.s)}, ${pct(state.v)}`;
  valHsl.textContent  = `${Math.round(hsl.h)}deg, ${pct(hsl.s)}, ${pct(hsl.l)}`;
  valCmyk.textContent = `${pct(cmyk.c)}, ${pct(cmyk.m)}, ${pct(cmyk.y)}, ${pct(cmyk.k)}`;

  // 色を作る面
  const hueNow = Math.round(state.h);
  if (hueNow !== lastHue) {
    drawSvPlane();
    lastHue = hueNow;
  }
  svCursor.style.left = (state.s * 100) + '%';
  svCursor.style.top  = ((1 - state.v) * 100) + '%';
  svCursor.style.background = hex;
}

/**
 * 色を決め直して、画面全体を揃える。
 * @param {{r:number,g:number,b:number}} rgb
 * @param {{hsv?:object, commit?:boolean}} options commit:true でパレットに残す
 */
function setColor(rgb, options) {
  const opt = options || {};
  state.r = clamp(Math.round(rgb.r), 0, 255);
  state.g = clamp(Math.round(rgb.g), 0, 255);
  state.b = clamp(Math.round(rgb.b), 0, 255);

  if (opt.hsv) {
    // 色を作る面や色相スライダーから来たときは、そこで指定された値をそのまま使う
    state.h = opt.hsv.h;
    state.s = opt.hsv.s;
    state.v = opt.hsv.v;
  } else {
    const hsv = rgbToHsv(state.r, state.g, state.b);
    // 白黒・灰色は色あいが決まらないので、直前の色あいを引き継ぐ
    state.h = hsv.s === 0 ? state.h : hsv.h;
    state.s = hsv.v === 0 ? state.s : hsv.s;
    state.v = hsv.v;
  }

  render();
  if (opt.commit) addToPalette(hexOf());
}

/* ==================================================================
   4. 上段：画像パネル
   ================================================================== */

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('画像を読み込めませんでした'));
    img.src = src;
  });
}

function setImage(img) {
  const w = img.naturalWidth || img.width;
  const h = img.naturalHeight || img.height;
  if (!w || !h) {
    toast('この画像は開けませんでした。別の画像でお試しください', 'warn');
    return false;
  }
  if (w > MAX_IMAGE_SIDE || h > MAX_IMAGE_SIDE) {
    toast(`画像が大きすぎます（縦横 ${MAX_IMAGE_SIDE}px までの画像でお試しください）`, 'warn');
    return false;
  }

  srcCanvas.width = w;
  srcCanvas.height = h;
  srcCtx.clearRect(0, 0, w, h);
  srcCtx.drawImage(img, 0, 0);

  hasImage = true;
  marker = null;
  imageSizeEl.textContent = `${w} x ${h}`;
  dropzone.classList.add('has-image');
  dropzone.setAttribute('aria-label', '画像。押すとその1点の色を取り出します');
  coordText.textContent = '画像の上をクリックすると、その1点の色を取り出します';
  computeLayout();
  drawView();
  return true;
}

/** 720×420 の中に、縦横の比を保ったまま中央に収める */
function computeLayout() {
  const cw = viewCanvas.width;
  const ch = viewCanvas.height;
  const scale = Math.min(cw / srcCanvas.width, ch / srcCanvas.height, 1);
  const dw = srcCanvas.width * scale;
  const dh = srcCanvas.height * scale;
  layout = {
    scale,
    dw, dh,
    dx: Math.round((cw - dw) / 2),
    dy: Math.round((ch - dh) / 2)
  };
}

function drawView() {
  viewCtx.clearRect(0, 0, viewCanvas.width, viewCanvas.height);
  viewCtx.fillStyle = '#fbf9f5';
  viewCtx.fillRect(0, 0, viewCanvas.width, viewCanvas.height);
  if (!hasImage || !layout) return;

  viewCtx.imageSmoothingEnabled = true;
  viewCtx.drawImage(
    srcCanvas,
    0, 0, srcCanvas.width, srcCanvas.height,
    layout.dx, layout.dy, layout.dw, layout.dh
  );

  if (marker) drawMarker();
}

function drawMarker() {
  const x = layout.dx + (marker.x + 0.5) * layout.scale;
  const y = layout.dy + (marker.y + 0.5) * layout.scale;
  viewCtx.save();
  viewCtx.lineWidth = 3;
  viewCtx.strokeStyle = 'rgba(255,255,255,.95)';
  viewCtx.beginPath();
  viewCtx.arc(x, y, 8, 0, Math.PI * 2);
  viewCtx.stroke();
  viewCtx.lineWidth = 1.5;
  viewCtx.strokeStyle = 'rgba(30,40,38,.9)';
  viewCtx.beginPath();
  viewCtx.arc(x, y, 8, 0, Math.PI * 2);
  viewCtx.stroke();
  viewCtx.beginPath();
  viewCtx.arc(x, y, 1.5, 0, Math.PI * 2);
  viewCtx.fillStyle = 'rgba(30,40,38,.9)';
  viewCtx.fill();
  viewCtx.restore();
}

/** 画面上の位置 → 元画像の何ピクセル目か（画像の外なら null） */
function pointToSource(clientX, clientY) {
  if (!hasImage || !layout) return null;
  const rect = viewCanvas.getBoundingClientRect();
  if (!rect.width || !rect.height) return null;
  const cx = (clientX - rect.left) * (viewCanvas.width / rect.width);
  const cy = (clientY - rect.top) * (viewCanvas.height / rect.height);
  const sx = Math.floor((cx - layout.dx) / layout.scale);
  const sy = Math.floor((cy - layout.dy) / layout.scale);
  if (sx < 0 || sy < 0 || sx >= srcCanvas.width || sy >= srcCanvas.height) return null;
  return { x: sx, y: sy };
}

/* ---- ルーペ ---- */

const LOUPE_CELLS = 15;                       // 何ピクセル四方を見せるか
const LOUPE_SIZE  = 132;                      // ルーペの大きさ
const LOUPE_ZOOM  = LOUPE_SIZE / LOUPE_CELLS; // 1ピクセルあたりの拡大率

function drawLoupe(p) {
  loupeCtx.imageSmoothingEnabled = false;
  loupeCtx.clearRect(0, 0, LOUPE_SIZE, LOUPE_SIZE);
  loupeCtx.fillStyle = '#efeae1';
  loupeCtx.fillRect(0, 0, LOUPE_SIZE, LOUPE_SIZE);

  const half = Math.floor(LOUPE_CELLS / 2);
  let sx = p.x - half, sy = p.y - half;
  let sw = LOUPE_CELLS, sh = LOUPE_CELLS;
  let dx = 0, dy = 0;

  // 画像の端では、はみ出した分を削って位置をずらす
  if (sx < 0) { dx = -sx * LOUPE_ZOOM; sw += sx; sx = 0; }
  if (sy < 0) { dy = -sy * LOUPE_ZOOM; sh += sy; sy = 0; }
  if (sx + sw > srcCanvas.width)  sw = srcCanvas.width - sx;
  if (sy + sh > srcCanvas.height) sh = srcCanvas.height - sy;

  if (sw > 0 && sh > 0) {
    loupeCtx.drawImage(srcCanvas, sx, sy, sw, sh, dx, dy, sw * LOUPE_ZOOM, sh * LOUPE_ZOOM);
  }
  drawCrosshair();
}

function drawCrosshair() {
  const c = LOUPE_SIZE / 2;
  const g = LOUPE_ZOOM / 2;   // 中央の1マスぶんは線を空ける
  const lines = [
    [c, 0, c, c - g], [c, c + g, c, LOUPE_SIZE],
    [0, c, c - g, c], [c + g, c, LOUPE_SIZE, c]
  ];
  const paint = (width, color) => {
    loupeCtx.lineWidth = width;
    loupeCtx.strokeStyle = color;
    loupeCtx.beginPath();
    lines.forEach(([x1, y1, x2, y2]) => {
      loupeCtx.moveTo(x1, y1);
      loupeCtx.lineTo(x2, y2);
    });
    loupeCtx.stroke();
    loupeCtx.strokeRect(c - g, c - g, LOUPE_ZOOM, LOUPE_ZOOM);
  };
  paint(3, 'rgba(255,255,255,.9)');
  paint(1, 'rgba(30,40,38,.85)');
}

function moveLoupe(clientX, clientY) {
  const box = LOUPE_SIZE + 16;
  let x = clientX + 20;
  let y = clientY + 20;
  if (x + box > window.innerWidth)  x = clientX - box - 20;
  if (y + box > window.innerHeight) y = clientY - box - 20;
  loupe.style.transform = `translate(${Math.max(4, x)}px, ${Math.max(4, y)}px)`;
}

function hideLoupe() {
  loupe.classList.remove('is-on');
}

/* ---- 画像の読み込み（4通り） ---- */

async function loadFromFile(file) {
  if (!file) return;
  if (!file.type || !file.type.startsWith('image/')) {
    toast('画像のファイルを選んでください（jpg・png・gif・webp など）', 'warn');
    return;
  }
  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url);
    if (setImage(img)) toast('画像を読み込みました');
  } catch (e) {
    toast('この画像は開けませんでした。別の画像でお試しください', 'warn');
  } finally {
    URL.revokeObjectURL(url);
  }
}

async function loadFromUrl(rawUrl) {
  const url = (rawUrl || '').trim();
  if (!url) {
    toast('画像のURLを入力してから「読み込む」を押してください', 'warn');
    urlInput.focus();
    return;
  }
  btnLoad.disabled = true;
  let objectUrl = '';
  try {
    const res = await fetch(url, { cache: 'no-cache' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const blob = await res.blob();
    if (!blob.type || !blob.type.startsWith('image/')) throw new Error('画像ではありません');
    objectUrl = URL.createObjectURL(blob);
    const img = await loadImage(objectUrl);
    if (setImage(img)) toast('画像を読み込みました');
  } catch (e) {
    toast('画像を読み込めませんでした。URLが正しいか確かめるか、別の画像でお試しください', 'warn');
  } finally {
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    btnLoad.disabled = false;
  }
}

function clearImage() {
  hasImage = false;
  marker = null;
  layout = null;
  srcCanvas.width = 1;
  srcCanvas.height = 1;
  imageSizeEl.textContent = '画像なし';
  dropzone.classList.remove('has-image');
  dropzone.setAttribute('aria-label', '画像を読み込む。押すとファイル選択が開きます');
  coordText.textContent = '画像の上をクリックすると、その1点の色を取り出します';
  urlInput.value = '';
  fileInput.value = '';
  hideLoupe();
  drawView();
}

/* ---- 画像パネルの操作をつなぐ ---- */

dropzone.addEventListener('click', (e) => {
  // 画像がまだ無いときだけ、ファイル選択を開く
  if (!hasImage) {
    fileInput.click();
    return;
  }
  const p = pointToSource(e.clientX, e.clientY);
  if (!p) return;
  const data = srcCtx.getImageData(p.x, p.y, 1, 1).data;
  marker = p;
  drawView();
  coordText.textContent = `x: ${p.x}, y: ${p.y}`;
  setColor({ r: data[0], g: data[1], b: data[2] }, { commit: true });
  toast(`${hexOf()} を取り出しました`);
});

dropzone.addEventListener('keydown', (e) => {
  if (hasImage) return;
  if (e.key === 'Enter' || e.key === ' ') {
    e.preventDefault();
    fileInput.click();
  }
});

viewCanvas.addEventListener('mousemove', (e) => {
  if (!hasImage) { hideLoupe(); return; }
  const p = pointToSource(e.clientX, e.clientY);
  if (!p) { hideLoupe(); return; }
  drawLoupe(p);
  moveLoupe(e.clientX, e.clientY);
  loupe.classList.add('is-on');
});

dropzone.addEventListener('mouseleave', hideLoupe);
window.addEventListener('blur', hideLoupe);

fileInput.addEventListener('change', () => {
  const file = fileInput.files && fileInput.files[0];
  fileInput.value = '';   // 同じファイルをもう一度選んでも読み込めるようにする
  loadFromFile(file);
});

dropzone.addEventListener('dragover', (e) => {
  e.preventDefault();
  dropzone.classList.add('is-over');
});
dropzone.addEventListener('dragleave', () => dropzone.classList.remove('is-over'));
dropzone.addEventListener('drop', (e) => {
  e.preventDefault();
  dropzone.classList.remove('is-over');
  const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
  if (file) { loadFromFile(file); return; }
  const dropped = e.dataTransfer
    ? (e.dataTransfer.getData('text/uri-list') || e.dataTransfer.getData('text/plain'))
    : '';
  if (dropped) {
    urlInput.value = dropped.trim();
    loadFromUrl(dropped);
  }
});

// 画面のどこに落とされても、ブラウザが勝手に画像を開いてしまわないようにする
window.addEventListener('dragover', (e) => e.preventDefault());
window.addEventListener('drop', (e) => e.preventDefault());

function isTextField(el) {
  return !!el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA');
}

document.addEventListener('paste', (e) => {
  const items = (e.clipboardData && e.clipboardData.items) || [];
  for (let i = 0; i < items.length; i++) {
    if (items[i].type && items[i].type.startsWith('image/')) {
      const file = items[i].getAsFile();
      if (file) {
        e.preventDefault();
        loadFromFile(file);
        return;
      }
    }
  }
  // 入力欄で作業中なら、その入力を邪魔しない
  if (isTextField(document.activeElement)) return;
  const text = ((e.clipboardData && e.clipboardData.getData('text')) || '').trim();
  if (/^https?:\/\//i.test(text)) {
    e.preventDefault();
    urlInput.value = text;
    loadFromUrl(text);
  }
});

btnLoad.addEventListener('click', () => loadFromUrl(urlInput.value));
urlInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    loadFromUrl(urlInput.value);
  }
});
btnClear.addEventListener('click', () => {
  clearImage();
  toast('画像を消しました');
});

/* ==================================================================
   5. 下段：カラーミキサー
   ================================================================== */

function drawSvPlane() {
  const w = svCanvas.width;
  const h = svCanvas.height;
  svCtx.fillStyle = `hsl(${state.h}, 100%, 50%)`;
  svCtx.fillRect(0, 0, w, h);

  const toWhite = svCtx.createLinearGradient(0, 0, w, 0);
  toWhite.addColorStop(0, 'rgba(255,255,255,1)');
  toWhite.addColorStop(1, 'rgba(255,255,255,0)');
  svCtx.fillStyle = toWhite;
  svCtx.fillRect(0, 0, w, h);

  const toBlack = svCtx.createLinearGradient(0, 0, 0, h);
  toBlack.addColorStop(0, 'rgba(0,0,0,0)');
  toBlack.addColorStop(1, 'rgba(0,0,0,1)');
  svCtx.fillStyle = toBlack;
  svCtx.fillRect(0, 0, w, h);
}

let svDragging = false;

function pickFromSv(clientX, clientY, commit) {
  const rect = svCanvas.getBoundingClientRect();
  if (!rect.width || !rect.height) return;
  const s = clamp((clientX - rect.left) / rect.width, 0, 1);
  const v = 1 - clamp((clientY - rect.top) / rect.height, 0, 1);
  setColor(hsvToRgb(state.h, s, v), { hsv: { h: state.h, s, v }, commit });
}

svCanvas.addEventListener('pointerdown', (e) => {
  svDragging = true;
  try { svCanvas.setPointerCapture(e.pointerId); } catch (err) { /* 使えない環境では無視 */ }
  pickFromSv(e.clientX, e.clientY, false);
});
svCanvas.addEventListener('pointermove', (e) => {
  if (svDragging) pickFromSv(e.clientX, e.clientY, false);
});
function endSvDrag(e) {
  if (!svDragging) return;
  svDragging = false;
  try { svCanvas.releasePointerCapture(e.pointerId); } catch (err) { /* 無視 */ }
  pickFromSv(e.clientX, e.clientY, true);   // 指を離したところで色を確定
}
svCanvas.addEventListener('pointerup', endSvDrag);
svCanvas.addEventListener('pointercancel', () => { svDragging = false; });

// キーボードだけでも色を作れるように
svCanvas.addEventListener('keydown', (e) => {
  const step = e.shiftKey ? 0.1 : 0.02;
  let s = state.s, v = state.v;
  if (e.key === 'ArrowLeft')       s -= step;
  else if (e.key === 'ArrowRight') s += step;
  else if (e.key === 'ArrowUp')    v += step;
  else if (e.key === 'ArrowDown')  v -= step;
  else return;
  e.preventDefault();
  s = clamp(s, 0, 1);
  v = clamp(v, 0, 1);
  setColor(hsvToRgb(state.h, s, v), { hsv: { h: state.h, s, v }, commit: true });
});

hueRange.addEventListener('input', () => {
  const h = Number(hueRange.value);
  setColor(hsvToRgb(h, state.s, state.v), { hsv: { h, s: state.s, v: state.v } });
});
hueRange.addEventListener('change', () => {
  const h = Number(hueRange.value);
  setColor(hsvToRgb(h, state.s, state.v), { hsv: { h, s: state.s, v: state.v }, commit: true });
});

function flashError(el) {
  el.classList.add('is-error');
  setTimeout(() => el.classList.remove('is-error'), 900);
}

function commitHex() {
  const rgb = hexToRgb(hexInput.value);
  if (!rgb) {
    hexInput.value = hexOf();          // もとの値に戻す
    flashError(hexInput);
    toast('色コードが読み取れません。#のあとに3桁か6桁で入れてください（例：#2563eb）', 'warn');
    return;
  }
  setColor(rgb, { commit: true });
  hexInput.value = hexOf();
}

hexInput.addEventListener('change', commitHex);
hexInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    commitHex();
  }
});

function commitRgb() {
  const parts = [rInput, gInput, bInput].map((el) => {
    const n = Number(el.value);
    return Number.isFinite(n) && el.value.trim() !== '' ? clamp(Math.round(n), 0, 255) : null;
  });
  if (parts.some((n) => n === null)) {
    toast('R・G・B は 0〜255 の数字で入れてください', 'warn');
    rInput.value = String(state.r);
    gInput.value = String(state.g);
    bInput.value = String(state.b);
    return;
  }
  setColor({ r: parts[0], g: parts[1], b: parts[2] }, { commit: true });
  // 範囲外を入れた場合に、丸めた後の数値へ表示をそろえる
  rInput.value = String(state.r);
  gInput.value = String(state.g);
  bInput.value = String(state.b);
}

[rInput, gInput, bInput].forEach((el) => {
  el.addEventListener('change', commitRgb);
  el.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      commitRgb();
    }
  });
});

/* ---- コピー ---- */

function copyByTextarea(text) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.setAttribute('readonly', '');
  ta.style.position = 'fixed';
  ta.style.top = '-1000px';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  let ok = false;
  try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
  ta.remove();
  return ok;
}

async function copyText(text) {
  try {
    if (!navigator.clipboard || !navigator.clipboard.writeText) throw new Error('未対応');
    await navigator.clipboard.writeText(text);
    toast(`${text} をコピーしました`);
  } catch (e) {
    // 新しい方法が使えないときは、昔からの方法で写す（clipboardWrite 権限を使う場面）
    if (copyByTextarea(text)) toast(`${text} をコピーしました`);
    else toast('コピーできませんでした。値を選んで Ctrl＋C を押してください', 'warn');
  }
}

document.querySelectorAll('[data-copy]').forEach((btn) => {
  btn.addEventListener('click', () => {
    const target = $(btn.dataset.copy);
    if (target) copyText(target.textContent.trim());
  });
});

btnCopyHex.addEventListener('click', () => copyText(hexOf()));

/* ---- パレット履歴 ---- */

function renderPalette() {
  paletteList.textContent = '';
  if (!state.palette.length) {
    paletteList.appendChild(paletteEmpty);
    return;
  }
  state.palette.forEach((hex) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'chip';
    btn.style.background = hex;
    btn.title = hex;
    btn.setAttribute('aria-label', `${hex} に戻す`);
    btn.addEventListener('click', () => {
      const rgb = hexToRgb(hex);
      if (!rgb) return;
      setColor(rgb);                    // 戻すだけなので履歴には足さない
      toast(`${hex} に戻しました`);
    });
    paletteList.appendChild(btn);
  });
}

function addToPalette(hex) {
  const found = state.palette.indexOf(hex);
  if (found === 0) return;              // すでに先頭なら何もしない
  if (found > 0) state.palette.splice(found, 1);
  state.palette.unshift(hex);
  if (state.palette.length > PALETTE_MAX) state.palette.length = PALETTE_MAX;
  renderPalette();
  storeSet(PALETTE_KEY, state.palette);
}

btnResetPal.addEventListener('click', () => {
  if (!state.palette.length) {
    toast('消す色がありません');
    return;
  }
  // 元に戻せない操作なので、ここだけ確認する
  if (!window.confirm('取り出した色をすべて消します。よろしいですか？')) return;
  state.palette = [];
  renderPalette();
  storeSet(PALETTE_KEY, state.palette);
  toast('取り出した色をすべて消しました');
});

/* ==================================================================
   6. 小窓の操作
   ================================================================== */

let windowId = null;
let windowType = '';
let frameOffset = { x: 0, y: 0 };   // window.screenX と拡張機能から見た位置のずれ

async function detectWindow() {
  if (!canUseChromeWindows) {
    titlebar.classList.add('is-static');
    return;
  }
  try {
    const win = await chrome.windows.getCurrent();
    windowId = win.id;
    windowType = win.type;
    if (typeof win.left === 'number' && typeof win.top === 'number') {
      frameOffset = { x: win.left - window.screenX, y: win.top - window.screenY };
    }
    if (win.type !== 'popup') titlebar.classList.add('is-static');
  } catch (e) {
    titlebar.classList.add('is-static');
  }
}

let drag = null;

titlebar.addEventListener('pointerdown', (e) => {
  if (e.button !== 0) return;
  // タイトルバーの中のボタン・入力欄の上では、つかまない
  if (e.target.closest('button, input, select, textarea, a')) return;
  if (!canUseChromeWindows || windowId === null || windowType !== 'popup') return;

  drag = {
    left: window.screenX + frameOffset.x,
    top: window.screenY + frameOffset.y,
    fromX: e.screenX,
    fromY: e.screenY,
    next: null,
    raf: 0
  };
  try { titlebar.setPointerCapture(e.pointerId); } catch (err) { /* 無視 */ }
  titlebar.classList.add('is-dragging');
});

function flushDrag() {
  if (!drag) return;
  drag.raf = 0;
  const next = drag.next;
  if (!next) return;
  drag.next = null;
  chrome.windows.update(windowId, { left: next.left, top: next.top })
    .catch(() => { /* 動かせなかったときは、そのまま何もしない */ });
}

titlebar.addEventListener('pointermove', (e) => {
  if (!drag) return;
  drag.next = {
    left: Math.round(drag.left + (e.screenX - drag.fromX)),
    top: Math.round(drag.top + (e.screenY - drag.fromY))
  };
  // 動かす回数を画面の更新に合わせて間引く
  if (!drag.raf) drag.raf = requestAnimationFrame(flushDrag);
});

function endDrag(e) {
  if (!drag) return;
  if (drag.raf) cancelAnimationFrame(drag.raf);
  flushDrag();
  drag = null;
  titlebar.classList.remove('is-dragging');
  try { titlebar.releasePointerCapture(e.pointerId); } catch (err) { /* 無視 */ }
}

titlebar.addEventListener('pointerup', endDrag);
titlebar.addEventListener('pointercancel', endDrag);

btnClose.addEventListener('click', () => {
  if (canUseChromeWindows && windowId !== null && windowType === 'popup') {
    chrome.windows.remove(windowId).catch(() => window.close());
    return;
  }
  window.close();
});

btnHelp.addEventListener('click', () => {
  const url = inExtension ? chrome.runtime.getURL('index.html') : './index.html';
  window.open(url, '_blank', 'noopener');
});

/* ---- 画面から色を取る（EyeDropper） ---- */

const canUseEyeDropper = typeof window.EyeDropper === 'function';

btnEyeDrop.addEventListener('click', async () => {
  if (!canUseEyeDropper) {
    toast('このChromeでは画面取得に未対応です', 'warn');
    return;
  }
  try {
    const picked = await new window.EyeDropper().open();
    const rgb = hexToRgb(picked.sRGBHex);
    if (!rgb) {
      toast('色を取り出せませんでした。もう一度お試しください', 'warn');
      return;
    }
    setColor(rgb, { commit: true });
    toast(`${hexOf()} を取り出しました`);
  } catch (e) {
    // Esc で取り消したときもここに来る。その場合は何も知らせない
  }
});

if (!canUseEyeDropper) {
  btnEyeDrop.classList.add('is-off');
  btnEyeDrop.title = 'このChromeでは画面取得に未対応です';
}

/* ==================================================================
   立ち上げ
   ================================================================== */

async function init() {
  drawView();
  setColor({ r: state.r, g: state.g, b: state.b });
  detectWindow();

  const saved = await storeGet(PALETTE_KEY, []);
  state.palette = Array.isArray(saved)
    ? saved.filter((hex) => typeof hex === 'string' && hexToRgb(hex)).slice(0, PALETTE_MAX)
    : [];
  renderPalette();
}

init();
