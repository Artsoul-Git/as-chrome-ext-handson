# -*- coding: utf-8 -*-
"""
カラーピッカー用アイコン生成スクリプト

icons/ フォルダに 16 / 32 / 48 / 128 px の PNG を書き出します。
図案：色相リング（虹色の輪）＋ 中央に白いしずく（スポイトの一滴）

■ 使い方
    1. Python と Pillow が入っていることを確認する
         pip install pillow
    2. このファイルがある tools フォルダで実行する
         python make_icons.py
    3. 一つ上の icons フォルダに 4 枚の PNG が上書き保存される

■ 色や形を変えたいとき
    下の「調整できる値」だけを書き換えれば、全サイズに反映されます。
"""

import colorsys
import os
import sys

try:
    from PIL import Image, ImageDraw
except ImportError:
    sys.exit("Pillow が見つかりません。先に `pip install pillow` を実行してください。")

# ------------------------------------------------------------------
# 調整できる値
# ------------------------------------------------------------------
SIZES = (16, 32, 48, 128)          # 書き出すサイズ
BG_COLOR = (23, 64, 62, 255)       # 背景（深い藍緑）
DROP_COLOR = (255, 253, 248, 255)  # しずくの色
SS = 8                             # 内部で何倍に拡大して描くか（大きいほど滑らか）

RING_OUTER = 0.375                 # 色相リングの外側半径（正方形の一辺に対する比率）
RING_INNER = 0.215                 # 色相リングの内側半径
CORNER = 0.235                     # 角丸の半径
MARGIN = 0.045                     # 外周の余白
SEGMENTS = 180                     # 色相リングの分割数
# ------------------------------------------------------------------


def hue_color(deg):
    """0〜360 の角度を虹色に変換する。"""
    r, g, b = colorsys.hsv_to_rgb((deg % 360) / 360.0, 0.82, 1.0)
    return (int(r * 255), int(g * 255), int(b * 255), 255)


def draw_ring(draw, side):
    """色相リング（虹色の輪）を描く。"""
    cx = cy = side / 2
    outer = side * RING_OUTER
    inner = side * RING_INNER
    step = 360 / SEGMENTS
    for i in range(SEGMENTS):
        start = i * step
        # 隣とすき間ができないよう、少しだけ重ねる
        draw.pieslice(
            [cx - outer, cy - outer, cx + outer, cy + outer],
            start=start - 0.8,
            end=start + step + 0.8,
            fill=hue_color(start - 90),
        )
    # 中央をくり抜いて輪にする
    draw.ellipse([cx - inner, cy - inner, cx + inner, cy + inner], fill=BG_COLOR)


def draw_drop(draw, side):
    """中央に白いしずく（スポイトの一滴）を描く。"""
    cx = side / 2
    r = side * 0.125            # 下側の丸の半径
    cy = side * 0.560           # 下側の丸の中心
    apex = side * 0.320         # とがった先端の高さ
    draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=DROP_COLOR)
    # 丸の左右の接点から先端へ向かう三角形をつなげて、しずくの形にする
    draw.polygon(
        [(cx, apex), (cx - r * 0.94, cy + r * 0.34), (cx + r * 0.94, cy + r * 0.34)],
        fill=DROP_COLOR,
    )


def make_icon(size):
    side = size * SS
    img = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    m = side * MARGIN
    draw.rounded_rectangle(
        [m, m, side - m, side - m],
        radius=side * CORNER,
        fill=BG_COLOR,
    )
    draw_ring(draw, side)
    draw_drop(draw, side)

    return img.resize((size, size), Image.LANCZOS)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    out_dir = os.path.join(os.path.dirname(here), "icons")
    os.makedirs(out_dir, exist_ok=True)

    for size in SIZES:
        path = os.path.join(out_dir, "icon%d.png" % size)
        make_icon(size).save(path, "PNG", optimize=True)
        print("書き出しました: %s" % path)

    print("完了しました。%d 枚を更新しました。" % len(SIZES))


if __name__ == "__main__":
    main()
